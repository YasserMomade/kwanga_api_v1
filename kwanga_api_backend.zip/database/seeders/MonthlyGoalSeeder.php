<?php

namespace Database\Seeders;

use App\Models\MonthlyGoal;
use Illuminate\Database\Seeder;

class MonthlyGoalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        MonthlyGoal::factory(20)->create();
    }
}
